const example = {
    "time": "12/19/2012, 19:00:00",
    "level": "warn",
    "description": "Server asked for control mode schedule however there is no schedule to be set."
}

const example = {
    "time": "12/19/2012, 19:00:00",
    "level": "danger",
    "description": "Connection lost."
}