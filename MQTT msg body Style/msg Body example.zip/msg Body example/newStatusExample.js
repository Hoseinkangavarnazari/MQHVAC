const example = {
    "time": "12/19/2012, 19:00:00",
    "data": [{
            "sid": "a1s1",
            "humidity": 11,
            "temperature": 31
        },
        {
            "sid": "a1s2",
            "humidity": 13.2,
            "temperature": 31.07
        },

        {
            "sid": "a1s3",
            "humidity": 13.2,
            "temperature": 31.07
        },

        {
            "sid": "a1s4",
            "humidity": 13.2,
            "temperature": 31.07
        }
    ]
}

const example2 = {
    time: "12/19/2012, 19:00:00",
    data: [
        {
            "sid": "a2s1",
            "humidity": 11,
            "temperature": 31
        },
        {
            "sid": "a2s2",
            "humidity": 13.2,
            "temperature": 31.07
        },
        {
            "sid": "a2s3",
            "humidity": 13.2,
            "temperature": 31.07
        },
        {
            "sid": "a2s4",
            "humidity": 13.2,
            "temperature": 31.07
        }
    ]
}